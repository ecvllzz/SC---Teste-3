Gere uma sinopse enxuta do Supercaderno: 5–10 bullets com os pontos essenciais.

Regras:
- Foco em utilidade para revisão
- Sem floreios
